function createGame(){
    document.body.innerHTML = "";
    var containerDiv = createDiv();
    containerDiv.classList.add("colourContainer");
    document.body.appendChild(containerDiv);
    console.log(gameElements);


    //create box
    for(i = 0; i < gameElements.lenght; i++){
          var currentColor = gameElements[i];
          console.log("now processing createGame() : "+ currentColor);
          var boxDiv = createDiv();
          boxDiv.style.bgColor = currentColor;
          containerDiv.appendChild(boxDiv);
      }


}



function loadApp(){

  createGame();


}
window.onload = loadApp;
