window.gameElements = [
  "green",
  "red",
  "blue"
];
